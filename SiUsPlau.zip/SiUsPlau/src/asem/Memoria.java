package asem;

public class Memoria {
	public int delta = 0; //siguiente posicion de memoria libre relativa a la funcion donde esta
	public int max = 0; //maximo tam de la memoria estatica
}
