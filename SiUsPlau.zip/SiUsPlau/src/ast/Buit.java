package ast;

import asem.TablaAmbitos;

public class Buit extends E{
	
	  public Buit() {  }

	  public TipoE tipo() {return TipoE.IDBUIT;}   
	  public String toString() {return "buit";}  
	  
	  public void vincula(TablaAmbitos T) {
			
		}
}
