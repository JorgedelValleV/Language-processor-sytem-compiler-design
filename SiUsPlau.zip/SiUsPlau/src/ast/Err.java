package ast;

public class Err extends E{

	
	public TipoE tipo() {
		return null;
	}
	
	public String toString() {
		return "ERROR";
	}

}
