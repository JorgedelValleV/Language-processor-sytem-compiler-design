package tipado;

public enum TPrimitivo {
	INT,BOOL,REAL,BUIT
}
